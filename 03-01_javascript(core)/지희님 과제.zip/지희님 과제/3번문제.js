// 두 개의 숫자를 매개변수로 받아서 그 합을 반환하는 함수를 작성하세요.
// 함수를 물어보는 문제 
// 매개변수는 무엇인가? - 


/*function hello(num){

    return num;
}*/

function sum(num, num2) {
        return num + num2;
}; 


console.log(sum(1,2));