/*1. 
사용자가 입력한 숫자가 홀수인지 짝수인지 판별하는 함수를 작성하세요.

(if - else 문 이용하기)
- if-else 문 구조 외우기
- 함수 형태 외우기, 매개변수
 */

function isOdd(numbers) {

    if (numbers % 2 == 0) {
        console.log("짝수입니다.");
    }
    else {
        console.log("홀수입니다.");
    }

}
